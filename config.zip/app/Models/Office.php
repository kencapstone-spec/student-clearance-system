<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Office extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'group',
        'sort_order',
        'is_final_approver',
    ];

    protected $casts = [
        'is_final_approver' => 'boolean',
    ];

    public function users(): HasMany
    {
        return $this->hasMany(User::class);
    }

    public function clearanceApprovals(): HasMany
    {
        return $this->hasMany(ClearanceApproval::class);
    }

    public function courses(): BelongsToMany
    {
        return $this->belongsToMany(Course::class);
    }

    public function prerequisites(): BelongsToMany
    {
        return $this->belongsToMany(Office::class, 'office_prerequisites', 'office_id', 'prerequisite_office_id');
    }
}
