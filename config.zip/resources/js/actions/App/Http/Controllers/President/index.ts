import FinalApprovalController from './FinalApprovalController'
const President = {
    FinalApprovalController: Object.assign(FinalApprovalController, FinalApprovalController),
}

export default President