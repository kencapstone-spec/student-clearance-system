import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Staff\PendingRequestController::index
 * @see app/Http/Controllers/Staff/PendingRequestController.php:16
 * @route '/staff/pending-requests'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/staff/pending-requests',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Staff\PendingRequestController::index
 * @see app/Http/Controllers/Staff/PendingRequestController.php:16
 * @route '/staff/pending-requests'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Staff\PendingRequestController::index
 * @see app/Http/Controllers/Staff/PendingRequestController.php:16
 * @route '/staff/pending-requests'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Staff\PendingRequestController::index
 * @see app/Http/Controllers/Staff/PendingRequestController.php:16
 * @route '/staff/pending-requests'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Staff\PendingRequestController::index
 * @see app/Http/Controllers/Staff/PendingRequestController.php:16
 * @route '/staff/pending-requests'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Staff\PendingRequestController::index
 * @see app/Http/Controllers/Staff/PendingRequestController.php:16
 * @route '/staff/pending-requests'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Staff\PendingRequestController::index
 * @see app/Http/Controllers/Staff/PendingRequestController.php:16
 * @route '/staff/pending-requests'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Staff\PendingRequestController::approveAll
 * @see app/Http/Controllers/Staff/PendingRequestController.php:75
 * @route '/staff/clearance-approvals/approve-all'
 */
export const approveAll = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: approveAll.url(options),
    method: 'patch',
})

approveAll.definition = {
    methods: ["patch"],
    url: '/staff/clearance-approvals/approve-all',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Staff\PendingRequestController::approveAll
 * @see app/Http/Controllers/Staff/PendingRequestController.php:75
 * @route '/staff/clearance-approvals/approve-all'
 */
approveAll.url = (options?: RouteQueryOptions) => {
    return approveAll.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Staff\PendingRequestController::approveAll
 * @see app/Http/Controllers/Staff/PendingRequestController.php:75
 * @route '/staff/clearance-approvals/approve-all'
 */
approveAll.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: approveAll.url(options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Staff\PendingRequestController::approveAll
 * @see app/Http/Controllers/Staff/PendingRequestController.php:75
 * @route '/staff/clearance-approvals/approve-all'
 */
    const approveAllForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approveAll.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Staff\PendingRequestController::approveAll
 * @see app/Http/Controllers/Staff/PendingRequestController.php:75
 * @route '/staff/clearance-approvals/approve-all'
 */
        approveAllForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approveAll.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    approveAll.form = approveAllForm
/**
* @see \App\Http\Controllers\Staff\PendingRequestController::approve
 * @see app/Http/Controllers/Staff/PendingRequestController.php:44
 * @route '/staff/clearance-approvals/{approval}/approve'
 */
export const approve = (args: { approval: string | number | { id: string | number } } | [approval: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: approve.url(args, options),
    method: 'patch',
})

approve.definition = {
    methods: ["patch"],
    url: '/staff/clearance-approvals/{approval}/approve',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Staff\PendingRequestController::approve
 * @see app/Http/Controllers/Staff/PendingRequestController.php:44
 * @route '/staff/clearance-approvals/{approval}/approve'
 */
approve.url = (args: { approval: string | number | { id: string | number } } | [approval: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { approval: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { approval: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    approval: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        approval: typeof args.approval === 'object'
                ? args.approval.id
                : args.approval,
                }

    return approve.definition.url
            .replace('{approval}', parsedArgs.approval.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Staff\PendingRequestController::approve
 * @see app/Http/Controllers/Staff/PendingRequestController.php:44
 * @route '/staff/clearance-approvals/{approval}/approve'
 */
approve.patch = (args: { approval: string | number | { id: string | number } } | [approval: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: approve.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Staff\PendingRequestController::approve
 * @see app/Http/Controllers/Staff/PendingRequestController.php:44
 * @route '/staff/clearance-approvals/{approval}/approve'
 */
    const approveForm = (args: { approval: string | number | { id: string | number } } | [approval: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approve.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Staff\PendingRequestController::approve
 * @see app/Http/Controllers/Staff/PendingRequestController.php:44
 * @route '/staff/clearance-approvals/{approval}/approve'
 */
        approveForm.patch = (args: { approval: string | number | { id: string | number } } | [approval: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approve.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    approve.form = approveForm
/**
* @see \App\Http\Controllers\Staff\PendingRequestController::reject
 * @see app/Http/Controllers/Staff/PendingRequestController.php:121
 * @route '/staff/clearance-approvals/{approval}/reject'
 */
export const reject = (args: { approval: string | number | { id: string | number } } | [approval: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: reject.url(args, options),
    method: 'patch',
})

reject.definition = {
    methods: ["patch"],
    url: '/staff/clearance-approvals/{approval}/reject',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Staff\PendingRequestController::reject
 * @see app/Http/Controllers/Staff/PendingRequestController.php:121
 * @route '/staff/clearance-approvals/{approval}/reject'
 */
reject.url = (args: { approval: string | number | { id: string | number } } | [approval: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { approval: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { approval: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    approval: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        approval: typeof args.approval === 'object'
                ? args.approval.id
                : args.approval,
                }

    return reject.definition.url
            .replace('{approval}', parsedArgs.approval.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Staff\PendingRequestController::reject
 * @see app/Http/Controllers/Staff/PendingRequestController.php:121
 * @route '/staff/clearance-approvals/{approval}/reject'
 */
reject.patch = (args: { approval: string | number | { id: string | number } } | [approval: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: reject.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Staff\PendingRequestController::reject
 * @see app/Http/Controllers/Staff/PendingRequestController.php:121
 * @route '/staff/clearance-approvals/{approval}/reject'
 */
    const rejectForm = (args: { approval: string | number | { id: string | number } } | [approval: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reject.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Staff\PendingRequestController::reject
 * @see app/Http/Controllers/Staff/PendingRequestController.php:121
 * @route '/staff/clearance-approvals/{approval}/reject'
 */
        rejectForm.patch = (args: { approval: string | number | { id: string | number } } | [approval: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reject.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    reject.form = rejectForm
const PendingRequestController = { index, approveAll, approve, reject }

export default PendingRequestController