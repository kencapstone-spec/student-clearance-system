import PendingRequestController from './PendingRequestController'
const Staff = {
    PendingRequestController: Object.assign(PendingRequestController, PendingRequestController),
}

export default Staff