import NotificationController from './NotificationController'
const Notifications = {
    NotificationController: Object.assign(NotificationController, NotificationController),
}

export default Notifications