import ClearanceRequestController from './ClearanceRequestController'
const Student = {
    ClearanceRequestController: Object.assign(ClearanceRequestController, ClearanceRequestController),
}

export default Student