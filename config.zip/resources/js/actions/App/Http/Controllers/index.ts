import ClearanceReceipt from './ClearanceReceipt'
import Notifications from './Notifications'
import Student from './Student'
import Staff from './Staff'
import Admin from './Admin'
import President from './President'
const Controllers = {
    ClearanceReceipt: Object.assign(ClearanceReceipt, ClearanceReceipt),
Notifications: Object.assign(Notifications, Notifications),
Student: Object.assign(Student, Student),
Staff: Object.assign(Staff, Staff),
Admin: Object.assign(Admin, Admin),
President: Object.assign(President, President),
}

export default Controllers