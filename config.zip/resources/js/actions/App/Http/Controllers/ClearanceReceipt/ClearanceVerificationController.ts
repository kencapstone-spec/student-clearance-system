import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\ClearanceReceipt\ClearanceVerificationController::show
 * @see app/Http/Controllers/ClearanceReceipt/ClearanceVerificationController.php:14
 * @route '/verify-clearance/{verificationCode}'
 */
export const show = (args: { verificationCode: string | number } | [verificationCode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/verify-clearance/{verificationCode}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ClearanceReceipt\ClearanceVerificationController::show
 * @see app/Http/Controllers/ClearanceReceipt/ClearanceVerificationController.php:14
 * @route '/verify-clearance/{verificationCode}'
 */
show.url = (args: { verificationCode: string | number } | [verificationCode: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { verificationCode: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    verificationCode: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        verificationCode: args.verificationCode,
                }

    return show.definition.url
            .replace('{verificationCode}', parsedArgs.verificationCode.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClearanceReceipt\ClearanceVerificationController::show
 * @see app/Http/Controllers/ClearanceReceipt/ClearanceVerificationController.php:14
 * @route '/verify-clearance/{verificationCode}'
 */
show.get = (args: { verificationCode: string | number } | [verificationCode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ClearanceReceipt\ClearanceVerificationController::show
 * @see app/Http/Controllers/ClearanceReceipt/ClearanceVerificationController.php:14
 * @route '/verify-clearance/{verificationCode}'
 */
show.head = (args: { verificationCode: string | number } | [verificationCode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ClearanceReceipt\ClearanceVerificationController::show
 * @see app/Http/Controllers/ClearanceReceipt/ClearanceVerificationController.php:14
 * @route '/verify-clearance/{verificationCode}'
 */
    const showForm = (args: { verificationCode: string | number } | [verificationCode: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ClearanceReceipt\ClearanceVerificationController::show
 * @see app/Http/Controllers/ClearanceReceipt/ClearanceVerificationController.php:14
 * @route '/verify-clearance/{verificationCode}'
 */
        showForm.get = (args: { verificationCode: string | number } | [verificationCode: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ClearanceReceipt\ClearanceVerificationController::show
 * @see app/Http/Controllers/ClearanceReceipt/ClearanceVerificationController.php:14
 * @route '/verify-clearance/{verificationCode}'
 */
        showForm.head = (args: { verificationCode: string | number } | [verificationCode: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const ClearanceVerificationController = { show }

export default ClearanceVerificationController