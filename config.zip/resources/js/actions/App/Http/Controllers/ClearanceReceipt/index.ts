import ClearanceVerificationController from './ClearanceVerificationController'
import ClearanceReceiptController from './ClearanceReceiptController'
const ClearanceReceipt = {
    ClearanceVerificationController: Object.assign(ClearanceVerificationController, ClearanceVerificationController),
ClearanceReceiptController: Object.assign(ClearanceReceiptController, ClearanceReceiptController),
}

export default ClearanceReceipt