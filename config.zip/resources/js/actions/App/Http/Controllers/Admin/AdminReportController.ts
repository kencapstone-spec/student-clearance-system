import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AdminReportController::index
 * @see app/Http/Controllers/Admin/AdminReportController.php:16
 * @route '/admin/reports'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/reports',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminReportController::index
 * @see app/Http/Controllers/Admin/AdminReportController.php:16
 * @route '/admin/reports'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminReportController::index
 * @see app/Http/Controllers/Admin/AdminReportController.php:16
 * @route '/admin/reports'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AdminReportController::index
 * @see app/Http/Controllers/Admin/AdminReportController.php:16
 * @route '/admin/reports'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AdminReportController::index
 * @see app/Http/Controllers/Admin/AdminReportController.php:16
 * @route '/admin/reports'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminReportController::index
 * @see app/Http/Controllers/Admin/AdminReportController.php:16
 * @route '/admin/reports'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AdminReportController::index
 * @see app/Http/Controllers/Admin/AdminReportController.php:16
 * @route '/admin/reports'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\AdminReportController::exportCsv
 * @see app/Http/Controllers/Admin/AdminReportController.php:61
 * @route '/admin/reports/export-csv'
 */
export const exportCsv = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportCsv.url(options),
    method: 'get',
})

exportCsv.definition = {
    methods: ["get","head"],
    url: '/admin/reports/export-csv',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminReportController::exportCsv
 * @see app/Http/Controllers/Admin/AdminReportController.php:61
 * @route '/admin/reports/export-csv'
 */
exportCsv.url = (options?: RouteQueryOptions) => {
    return exportCsv.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminReportController::exportCsv
 * @see app/Http/Controllers/Admin/AdminReportController.php:61
 * @route '/admin/reports/export-csv'
 */
exportCsv.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportCsv.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AdminReportController::exportCsv
 * @see app/Http/Controllers/Admin/AdminReportController.php:61
 * @route '/admin/reports/export-csv'
 */
exportCsv.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportCsv.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AdminReportController::exportCsv
 * @see app/Http/Controllers/Admin/AdminReportController.php:61
 * @route '/admin/reports/export-csv'
 */
    const exportCsvForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportCsv.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminReportController::exportCsv
 * @see app/Http/Controllers/Admin/AdminReportController.php:61
 * @route '/admin/reports/export-csv'
 */
        exportCsvForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportCsv.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AdminReportController::exportCsv
 * @see app/Http/Controllers/Admin/AdminReportController.php:61
 * @route '/admin/reports/export-csv'
 */
        exportCsvForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportCsv.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportCsv.form = exportCsvForm
/**
* @see \App\Http\Controllers\Admin\AdminReportController::printReport
 * @see app/Http/Controllers/Admin/AdminReportController.php:105
 * @route '/admin/reports/print'
 */
export const printReport = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: printReport.url(options),
    method: 'get',
})

printReport.definition = {
    methods: ["get","head"],
    url: '/admin/reports/print',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminReportController::printReport
 * @see app/Http/Controllers/Admin/AdminReportController.php:105
 * @route '/admin/reports/print'
 */
printReport.url = (options?: RouteQueryOptions) => {
    return printReport.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminReportController::printReport
 * @see app/Http/Controllers/Admin/AdminReportController.php:105
 * @route '/admin/reports/print'
 */
printReport.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: printReport.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AdminReportController::printReport
 * @see app/Http/Controllers/Admin/AdminReportController.php:105
 * @route '/admin/reports/print'
 */
printReport.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: printReport.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AdminReportController::printReport
 * @see app/Http/Controllers/Admin/AdminReportController.php:105
 * @route '/admin/reports/print'
 */
    const printReportForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: printReport.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminReportController::printReport
 * @see app/Http/Controllers/Admin/AdminReportController.php:105
 * @route '/admin/reports/print'
 */
        printReportForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: printReport.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AdminReportController::printReport
 * @see app/Http/Controllers/Admin/AdminReportController.php:105
 * @route '/admin/reports/print'
 */
        printReportForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: printReport.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    printReport.form = printReportForm
const AdminReportController = { index, exportCsv, printReport }

export default AdminReportController