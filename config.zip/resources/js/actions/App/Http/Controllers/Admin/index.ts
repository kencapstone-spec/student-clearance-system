import AdminCourseModuleController from './AdminCourseModuleController'
import AdminOfficePrerequisiteController from './AdminOfficePrerequisiteController'
import AdminDashboardController from './AdminDashboardController'
import AdminUserController from './AdminUserController'
import AdminClearanceRequestController from './AdminClearanceRequestController'
import AdminReportController from './AdminReportController'
import AdminSettingController from './AdminSettingController'
const Admin = {
    AdminCourseModuleController: Object.assign(AdminCourseModuleController, AdminCourseModuleController),
AdminOfficePrerequisiteController: Object.assign(AdminOfficePrerequisiteController, AdminOfficePrerequisiteController),
AdminDashboardController: Object.assign(AdminDashboardController, AdminDashboardController),
AdminUserController: Object.assign(AdminUserController, AdminUserController),
AdminClearanceRequestController: Object.assign(AdminClearanceRequestController, AdminClearanceRequestController),
AdminReportController: Object.assign(AdminReportController, AdminReportController),
AdminSettingController: Object.assign(AdminSettingController, AdminSettingController),
}

export default Admin