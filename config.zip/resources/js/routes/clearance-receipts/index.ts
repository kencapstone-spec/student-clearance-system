import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\ClearanceReceipt\ClearanceReceiptController::show
 * @see app/Http/Controllers/ClearanceReceipt/ClearanceReceiptController.php:20
 * @route '/clearance-receipts/{clearanceRequest}'
 */
export const show = (args: { clearanceRequest: string | number | { id: string | number } } | [clearanceRequest: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/clearance-receipts/{clearanceRequest}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ClearanceReceipt\ClearanceReceiptController::show
 * @see app/Http/Controllers/ClearanceReceipt/ClearanceReceiptController.php:20
 * @route '/clearance-receipts/{clearanceRequest}'
 */
show.url = (args: { clearanceRequest: string | number | { id: string | number } } | [clearanceRequest: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { clearanceRequest: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { clearanceRequest: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    clearanceRequest: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        clearanceRequest: typeof args.clearanceRequest === 'object'
                ? args.clearanceRequest.id
                : args.clearanceRequest,
                }

    return show.definition.url
            .replace('{clearanceRequest}', parsedArgs.clearanceRequest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClearanceReceipt\ClearanceReceiptController::show
 * @see app/Http/Controllers/ClearanceReceipt/ClearanceReceiptController.php:20
 * @route '/clearance-receipts/{clearanceRequest}'
 */
show.get = (args: { clearanceRequest: string | number | { id: string | number } } | [clearanceRequest: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ClearanceReceipt\ClearanceReceiptController::show
 * @see app/Http/Controllers/ClearanceReceipt/ClearanceReceiptController.php:20
 * @route '/clearance-receipts/{clearanceRequest}'
 */
show.head = (args: { clearanceRequest: string | number | { id: string | number } } | [clearanceRequest: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ClearanceReceipt\ClearanceReceiptController::show
 * @see app/Http/Controllers/ClearanceReceipt/ClearanceReceiptController.php:20
 * @route '/clearance-receipts/{clearanceRequest}'
 */
    const showForm = (args: { clearanceRequest: string | number | { id: string | number } } | [clearanceRequest: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ClearanceReceipt\ClearanceReceiptController::show
 * @see app/Http/Controllers/ClearanceReceipt/ClearanceReceiptController.php:20
 * @route '/clearance-receipts/{clearanceRequest}'
 */
        showForm.get = (args: { clearanceRequest: string | number | { id: string | number } } | [clearanceRequest: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ClearanceReceipt\ClearanceReceiptController::show
 * @see app/Http/Controllers/ClearanceReceipt/ClearanceReceiptController.php:20
 * @route '/clearance-receipts/{clearanceRequest}'
 */
        showForm.head = (args: { clearanceRequest: string | number | { id: string | number } } | [clearanceRequest: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\ClearanceReceipt\ClearanceReceiptController::download
 * @see app/Http/Controllers/ClearanceReceipt/ClearanceReceiptController.php:88
 * @route '/clearance-receipts/{clearanceRequest}/download'
 */
export const download = (args: { clearanceRequest: string | number | { id: string | number } } | [clearanceRequest: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})

download.definition = {
    methods: ["get","head"],
    url: '/clearance-receipts/{clearanceRequest}/download',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ClearanceReceipt\ClearanceReceiptController::download
 * @see app/Http/Controllers/ClearanceReceipt/ClearanceReceiptController.php:88
 * @route '/clearance-receipts/{clearanceRequest}/download'
 */
download.url = (args: { clearanceRequest: string | number | { id: string | number } } | [clearanceRequest: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { clearanceRequest: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { clearanceRequest: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    clearanceRequest: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        clearanceRequest: typeof args.clearanceRequest === 'object'
                ? args.clearanceRequest.id
                : args.clearanceRequest,
                }

    return download.definition.url
            .replace('{clearanceRequest}', parsedArgs.clearanceRequest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClearanceReceipt\ClearanceReceiptController::download
 * @see app/Http/Controllers/ClearanceReceipt/ClearanceReceiptController.php:88
 * @route '/clearance-receipts/{clearanceRequest}/download'
 */
download.get = (args: { clearanceRequest: string | number | { id: string | number } } | [clearanceRequest: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ClearanceReceipt\ClearanceReceiptController::download
 * @see app/Http/Controllers/ClearanceReceipt/ClearanceReceiptController.php:88
 * @route '/clearance-receipts/{clearanceRequest}/download'
 */
download.head = (args: { clearanceRequest: string | number | { id: string | number } } | [clearanceRequest: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: download.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ClearanceReceipt\ClearanceReceiptController::download
 * @see app/Http/Controllers/ClearanceReceipt/ClearanceReceiptController.php:88
 * @route '/clearance-receipts/{clearanceRequest}/download'
 */
    const downloadForm = (args: { clearanceRequest: string | number | { id: string | number } } | [clearanceRequest: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: download.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ClearanceReceipt\ClearanceReceiptController::download
 * @see app/Http/Controllers/ClearanceReceipt/ClearanceReceiptController.php:88
 * @route '/clearance-receipts/{clearanceRequest}/download'
 */
        downloadForm.get = (args: { clearanceRequest: string | number | { id: string | number } } | [clearanceRequest: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ClearanceReceipt\ClearanceReceiptController::download
 * @see app/Http/Controllers/ClearanceReceipt/ClearanceReceiptController.php:88
 * @route '/clearance-receipts/{clearanceRequest}/download'
 */
        downloadForm.head = (args: { clearanceRequest: string | number | { id: string | number } } | [clearanceRequest: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    download.form = downloadForm
const clearanceReceipts = {
    show: Object.assign(show, show),
download: Object.assign(download, download),
}

export default clearanceReceipts