import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Student\ClearanceRequestController::markAsComplied
 * @see app/Http/Controllers/Student/ClearanceRequestController.php:184
 * @route '/student/clearance-approvals/{approval}/mark-as-complied'
 */
export const markAsComplied = (args: { approval: string | number | { id: string | number } } | [approval: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: markAsComplied.url(args, options),
    method: 'patch',
})

markAsComplied.definition = {
    methods: ["patch"],
    url: '/student/clearance-approvals/{approval}/mark-as-complied',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Student\ClearanceRequestController::markAsComplied
 * @see app/Http/Controllers/Student/ClearanceRequestController.php:184
 * @route '/student/clearance-approvals/{approval}/mark-as-complied'
 */
markAsComplied.url = (args: { approval: string | number | { id: string | number } } | [approval: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { approval: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { approval: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    approval: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        approval: typeof args.approval === 'object'
                ? args.approval.id
                : args.approval,
                }

    return markAsComplied.definition.url
            .replace('{approval}', parsedArgs.approval.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\ClearanceRequestController::markAsComplied
 * @see app/Http/Controllers/Student/ClearanceRequestController.php:184
 * @route '/student/clearance-approvals/{approval}/mark-as-complied'
 */
markAsComplied.patch = (args: { approval: string | number | { id: string | number } } | [approval: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: markAsComplied.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Student\ClearanceRequestController::markAsComplied
 * @see app/Http/Controllers/Student/ClearanceRequestController.php:184
 * @route '/student/clearance-approvals/{approval}/mark-as-complied'
 */
    const markAsCompliedForm = (args: { approval: string | number | { id: string | number } } | [approval: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: markAsComplied.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Student\ClearanceRequestController::markAsComplied
 * @see app/Http/Controllers/Student/ClearanceRequestController.php:184
 * @route '/student/clearance-approvals/{approval}/mark-as-complied'
 */
        markAsCompliedForm.patch = (args: { approval: string | number | { id: string | number } } | [approval: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: markAsComplied.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    markAsComplied.form = markAsCompliedForm
const clearanceApprovals = {
    markAsComplied: Object.assign(markAsComplied, markAsComplied),
}

export default clearanceApprovals