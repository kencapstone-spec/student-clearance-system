import clearanceRequests from './clearance-requests'
import clearanceApprovals from './clearance-approvals'
const student = {
    clearanceRequests: Object.assign(clearanceRequests, clearanceRequests),
clearanceApprovals: Object.assign(clearanceApprovals, clearanceApprovals),
}

export default student