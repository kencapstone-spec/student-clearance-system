import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Student\ClearanceRequestController::store
 * @see app/Http/Controllers/Student/ClearanceRequestController.php:19
 * @route '/student/clearance-requests'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/student/clearance-requests',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Student\ClearanceRequestController::store
 * @see app/Http/Controllers/Student/ClearanceRequestController.php:19
 * @route '/student/clearance-requests'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\ClearanceRequestController::store
 * @see app/Http/Controllers/Student/ClearanceRequestController.php:19
 * @route '/student/clearance-requests'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Student\ClearanceRequestController::store
 * @see app/Http/Controllers/Student/ClearanceRequestController.php:19
 * @route '/student/clearance-requests'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Student\ClearanceRequestController::store
 * @see app/Http/Controllers/Student/ClearanceRequestController.php:19
 * @route '/student/clearance-requests'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Student\ClearanceRequestController::requestMoreOffices
 * @see app/Http/Controllers/Student/ClearanceRequestController.php:99
 * @route '/student/clearance-requests/request-more-offices'
 */
export const requestMoreOffices = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: requestMoreOffices.url(options),
    method: 'patch',
})

requestMoreOffices.definition = {
    methods: ["patch"],
    url: '/student/clearance-requests/request-more-offices',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Student\ClearanceRequestController::requestMoreOffices
 * @see app/Http/Controllers/Student/ClearanceRequestController.php:99
 * @route '/student/clearance-requests/request-more-offices'
 */
requestMoreOffices.url = (options?: RouteQueryOptions) => {
    return requestMoreOffices.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Student\ClearanceRequestController::requestMoreOffices
 * @see app/Http/Controllers/Student/ClearanceRequestController.php:99
 * @route '/student/clearance-requests/request-more-offices'
 */
requestMoreOffices.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: requestMoreOffices.url(options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Student\ClearanceRequestController::requestMoreOffices
 * @see app/Http/Controllers/Student/ClearanceRequestController.php:99
 * @route '/student/clearance-requests/request-more-offices'
 */
    const requestMoreOfficesForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: requestMoreOffices.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Student\ClearanceRequestController::requestMoreOffices
 * @see app/Http/Controllers/Student/ClearanceRequestController.php:99
 * @route '/student/clearance-requests/request-more-offices'
 */
        requestMoreOfficesForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: requestMoreOffices.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    requestMoreOffices.form = requestMoreOfficesForm
const clearanceRequests = {
    store: Object.assign(store, store),
requestMoreOffices: Object.assign(requestMoreOffices, requestMoreOffices),
}

export default clearanceRequests