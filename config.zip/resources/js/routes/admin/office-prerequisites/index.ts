import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AdminOfficePrerequisiteController::index
 * @see app/Http/Controllers/Admin/AdminOfficePrerequisiteController.php:12
 * @route '/admin/office-prerequisites'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/office-prerequisites',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminOfficePrerequisiteController::index
 * @see app/Http/Controllers/Admin/AdminOfficePrerequisiteController.php:12
 * @route '/admin/office-prerequisites'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminOfficePrerequisiteController::index
 * @see app/Http/Controllers/Admin/AdminOfficePrerequisiteController.php:12
 * @route '/admin/office-prerequisites'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AdminOfficePrerequisiteController::index
 * @see app/Http/Controllers/Admin/AdminOfficePrerequisiteController.php:12
 * @route '/admin/office-prerequisites'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AdminOfficePrerequisiteController::index
 * @see app/Http/Controllers/Admin/AdminOfficePrerequisiteController.php:12
 * @route '/admin/office-prerequisites'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminOfficePrerequisiteController::index
 * @see app/Http/Controllers/Admin/AdminOfficePrerequisiteController.php:12
 * @route '/admin/office-prerequisites'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AdminOfficePrerequisiteController::index
 * @see app/Http/Controllers/Admin/AdminOfficePrerequisiteController.php:12
 * @route '/admin/office-prerequisites'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\AdminOfficePrerequisiteController::update
 * @see app/Http/Controllers/Admin/AdminOfficePrerequisiteController.php:28
 * @route '/admin/office-prerequisites/{office}'
 */
export const update = (args: { office: string | number | { id: string | number } } | [office: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/admin/office-prerequisites/{office}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Admin\AdminOfficePrerequisiteController::update
 * @see app/Http/Controllers/Admin/AdminOfficePrerequisiteController.php:28
 * @route '/admin/office-prerequisites/{office}'
 */
update.url = (args: { office: string | number | { id: string | number } } | [office: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { office: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { office: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    office: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        office: typeof args.office === 'object'
                ? args.office.id
                : args.office,
                }

    return update.definition.url
            .replace('{office}', parsedArgs.office.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminOfficePrerequisiteController::update
 * @see app/Http/Controllers/Admin/AdminOfficePrerequisiteController.php:28
 * @route '/admin/office-prerequisites/{office}'
 */
update.patch = (args: { office: string | number | { id: string | number } } | [office: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\AdminOfficePrerequisiteController::update
 * @see app/Http/Controllers/Admin/AdminOfficePrerequisiteController.php:28
 * @route '/admin/office-prerequisites/{office}'
 */
    const updateForm = (args: { office: string | number | { id: string | number } } | [office: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminOfficePrerequisiteController::update
 * @see app/Http/Controllers/Admin/AdminOfficePrerequisiteController.php:28
 * @route '/admin/office-prerequisites/{office}'
 */
        updateForm.patch = (args: { office: string | number | { id: string | number } } | [office: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const officePrerequisites = {
    index: Object.assign(index, index),
update: Object.assign(update, update),
}

export default officePrerequisites