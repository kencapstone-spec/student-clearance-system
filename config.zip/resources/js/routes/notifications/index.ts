import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Notifications\NotificationController::open
 * @see app/Http/Controllers/Notifications/NotificationController.php:12
 * @route '/notifications/{notification}/open'
 */
export const open = (args: { notification: string | number | { id: string | number } } | [notification: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: open.url(args, options),
    method: 'get',
})

open.definition = {
    methods: ["get","head"],
    url: '/notifications/{notification}/open',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Notifications\NotificationController::open
 * @see app/Http/Controllers/Notifications/NotificationController.php:12
 * @route '/notifications/{notification}/open'
 */
open.url = (args: { notification: string | number | { id: string | number } } | [notification: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { notification: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { notification: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    notification: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        notification: typeof args.notification === 'object'
                ? args.notification.id
                : args.notification,
                }

    return open.definition.url
            .replace('{notification}', parsedArgs.notification.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Notifications\NotificationController::open
 * @see app/Http/Controllers/Notifications/NotificationController.php:12
 * @route '/notifications/{notification}/open'
 */
open.get = (args: { notification: string | number | { id: string | number } } | [notification: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: open.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Notifications\NotificationController::open
 * @see app/Http/Controllers/Notifications/NotificationController.php:12
 * @route '/notifications/{notification}/open'
 */
open.head = (args: { notification: string | number | { id: string | number } } | [notification: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: open.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Notifications\NotificationController::open
 * @see app/Http/Controllers/Notifications/NotificationController.php:12
 * @route '/notifications/{notification}/open'
 */
    const openForm = (args: { notification: string | number | { id: string | number } } | [notification: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: open.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Notifications\NotificationController::open
 * @see app/Http/Controllers/Notifications/NotificationController.php:12
 * @route '/notifications/{notification}/open'
 */
        openForm.get = (args: { notification: string | number | { id: string | number } } | [notification: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: open.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Notifications\NotificationController::open
 * @see app/Http/Controllers/Notifications/NotificationController.php:12
 * @route '/notifications/{notification}/open'
 */
        openForm.head = (args: { notification: string | number | { id: string | number } } | [notification: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: open.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    open.form = openForm
/**
* @see \App\Http\Controllers\Notifications\NotificationController::markAllAsRead
 * @see app/Http/Controllers/Notifications/NotificationController.php:27
 * @route '/notifications/mark-all-as-read'
 */
export const markAllAsRead = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: markAllAsRead.url(options),
    method: 'patch',
})

markAllAsRead.definition = {
    methods: ["patch"],
    url: '/notifications/mark-all-as-read',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Notifications\NotificationController::markAllAsRead
 * @see app/Http/Controllers/Notifications/NotificationController.php:27
 * @route '/notifications/mark-all-as-read'
 */
markAllAsRead.url = (options?: RouteQueryOptions) => {
    return markAllAsRead.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Notifications\NotificationController::markAllAsRead
 * @see app/Http/Controllers/Notifications/NotificationController.php:27
 * @route '/notifications/mark-all-as-read'
 */
markAllAsRead.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: markAllAsRead.url(options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Notifications\NotificationController::markAllAsRead
 * @see app/Http/Controllers/Notifications/NotificationController.php:27
 * @route '/notifications/mark-all-as-read'
 */
    const markAllAsReadForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: markAllAsRead.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Notifications\NotificationController::markAllAsRead
 * @see app/Http/Controllers/Notifications/NotificationController.php:27
 * @route '/notifications/mark-all-as-read'
 */
        markAllAsReadForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: markAllAsRead.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    markAllAsRead.form = markAllAsReadForm
const notifications = {
    open: Object.assign(open, open),
markAllAsRead: Object.assign(markAllAsRead, markAllAsRead),
}

export default notifications