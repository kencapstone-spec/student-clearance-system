import pendingRequests from './pending-requests'
import clearanceApprovals from './clearance-approvals'
const staff = {
    pendingRequests: Object.assign(pendingRequests, pendingRequests),
clearanceApprovals: Object.assign(clearanceApprovals, clearanceApprovals),
}

export default staff