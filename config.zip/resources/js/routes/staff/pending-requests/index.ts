import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Staff\PendingRequestController::index
 * @see app/Http/Controllers/Staff/PendingRequestController.php:16
 * @route '/staff/pending-requests'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/staff/pending-requests',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Staff\PendingRequestController::index
 * @see app/Http/Controllers/Staff/PendingRequestController.php:16
 * @route '/staff/pending-requests'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Staff\PendingRequestController::index
 * @see app/Http/Controllers/Staff/PendingRequestController.php:16
 * @route '/staff/pending-requests'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Staff\PendingRequestController::index
 * @see app/Http/Controllers/Staff/PendingRequestController.php:16
 * @route '/staff/pending-requests'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Staff\PendingRequestController::index
 * @see app/Http/Controllers/Staff/PendingRequestController.php:16
 * @route '/staff/pending-requests'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Staff\PendingRequestController::index
 * @see app/Http/Controllers/Staff/PendingRequestController.php:16
 * @route '/staff/pending-requests'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Staff\PendingRequestController::index
 * @see app/Http/Controllers/Staff/PendingRequestController.php:16
 * @route '/staff/pending-requests'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const pendingRequests = {
    index: Object.assign(index, index),
}

export default pendingRequests