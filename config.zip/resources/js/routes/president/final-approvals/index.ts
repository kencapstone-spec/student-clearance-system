import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\President\FinalApprovalController::index
 * @see app/Http/Controllers/President/FinalApprovalController.php:17
 * @route '/president/final-approvals'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/president/final-approvals',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\President\FinalApprovalController::index
 * @see app/Http/Controllers/President/FinalApprovalController.php:17
 * @route '/president/final-approvals'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\President\FinalApprovalController::index
 * @see app/Http/Controllers/President/FinalApprovalController.php:17
 * @route '/president/final-approvals'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\President\FinalApprovalController::index
 * @see app/Http/Controllers/President/FinalApprovalController.php:17
 * @route '/president/final-approvals'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\President\FinalApprovalController::index
 * @see app/Http/Controllers/President/FinalApprovalController.php:17
 * @route '/president/final-approvals'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\President\FinalApprovalController::index
 * @see app/Http/Controllers/President/FinalApprovalController.php:17
 * @route '/president/final-approvals'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\President\FinalApprovalController::index
 * @see app/Http/Controllers/President/FinalApprovalController.php:17
 * @route '/president/final-approvals'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\President\FinalApprovalController::approve
 * @see app/Http/Controllers/President/FinalApprovalController.php:30
 * @route '/president/final-approvals/{clearanceRequest}/approve'
 */
export const approve = (args: { clearanceRequest: string | number | { id: string | number } } | [clearanceRequest: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: approve.url(args, options),
    method: 'patch',
})

approve.definition = {
    methods: ["patch"],
    url: '/president/final-approvals/{clearanceRequest}/approve',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\President\FinalApprovalController::approve
 * @see app/Http/Controllers/President/FinalApprovalController.php:30
 * @route '/president/final-approvals/{clearanceRequest}/approve'
 */
approve.url = (args: { clearanceRequest: string | number | { id: string | number } } | [clearanceRequest: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { clearanceRequest: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { clearanceRequest: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    clearanceRequest: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        clearanceRequest: typeof args.clearanceRequest === 'object'
                ? args.clearanceRequest.id
                : args.clearanceRequest,
                }

    return approve.definition.url
            .replace('{clearanceRequest}', parsedArgs.clearanceRequest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\President\FinalApprovalController::approve
 * @see app/Http/Controllers/President/FinalApprovalController.php:30
 * @route '/president/final-approvals/{clearanceRequest}/approve'
 */
approve.patch = (args: { clearanceRequest: string | number | { id: string | number } } | [clearanceRequest: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: approve.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\President\FinalApprovalController::approve
 * @see app/Http/Controllers/President/FinalApprovalController.php:30
 * @route '/president/final-approvals/{clearanceRequest}/approve'
 */
    const approveForm = (args: { clearanceRequest: string | number | { id: string | number } } | [clearanceRequest: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approve.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\President\FinalApprovalController::approve
 * @see app/Http/Controllers/President/FinalApprovalController.php:30
 * @route '/president/final-approvals/{clearanceRequest}/approve'
 */
        approveForm.patch = (args: { clearanceRequest: string | number | { id: string | number } } | [clearanceRequest: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approve.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    approve.form = approveForm
/**
* @see \App\Http\Controllers\President\FinalApprovalController::approveAll
 * @see app/Http/Controllers/President/FinalApprovalController.php:52
 * @route '/president/final-approvals/approve-all'
 */
export const approveAll = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: approveAll.url(options),
    method: 'patch',
})

approveAll.definition = {
    methods: ["patch"],
    url: '/president/final-approvals/approve-all',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\President\FinalApprovalController::approveAll
 * @see app/Http/Controllers/President/FinalApprovalController.php:52
 * @route '/president/final-approvals/approve-all'
 */
approveAll.url = (options?: RouteQueryOptions) => {
    return approveAll.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\President\FinalApprovalController::approveAll
 * @see app/Http/Controllers/President/FinalApprovalController.php:52
 * @route '/president/final-approvals/approve-all'
 */
approveAll.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: approveAll.url(options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\President\FinalApprovalController::approveAll
 * @see app/Http/Controllers/President/FinalApprovalController.php:52
 * @route '/president/final-approvals/approve-all'
 */
    const approveAllForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approveAll.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\President\FinalApprovalController::approveAll
 * @see app/Http/Controllers/President/FinalApprovalController.php:52
 * @route '/president/final-approvals/approve-all'
 */
        approveAllForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approveAll.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    approveAll.form = approveAllForm
const finalApprovals = {
    index: Object.assign(index, index),
approve: Object.assign(approve, approve),
approveAll: Object.assign(approveAll, approveAll),
}

export default finalApprovals