import finalApprovals from './final-approvals'
const president = {
    finalApprovals: Object.assign(finalApprovals, finalApprovals),
}

export default president